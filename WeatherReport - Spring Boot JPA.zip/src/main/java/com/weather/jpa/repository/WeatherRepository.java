package com.weather.jpa.repository;

import org.springframework.stereotype.Repository;
import com.weather.jpa.domain.WeatherReport;
import org.springframework.data.repository.CrudRepository;

//Fill your code here
