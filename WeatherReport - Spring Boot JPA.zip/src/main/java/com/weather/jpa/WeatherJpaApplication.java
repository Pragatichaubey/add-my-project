package com.weather.jpa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//Fill your code here
public class WeatherJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(WeatherJpaApplication.class, args);
	}

}
